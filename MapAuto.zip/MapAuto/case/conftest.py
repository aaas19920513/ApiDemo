# -*- coding: utf-8 -*-
# @Time    : 2019/9/18 0:37
# @Author  : tuihou
# @File    : conftest.py

import pytest
from lib import log
import exception
from lib import Utils as U
import uiautomator2 as u2


class Driver(object):

    def __init__(self, device):
        self.device = device
        self.driver = u2.connect(self.device)

    def get_driver(self):
        return self.driver

    def start_app(self):
        self.driver.app_start('tv.danmaku.bili')

    def stop_app(self):
        self.driver.app_stop('tv.danmaku.bili')


##############################################################################################
def generate_device(device_list, i):
    """
    devices 生成器
    :param device_list:  devices列表
    :param i:  生成器起点位置
    :return:   device
    """
    while True:
        length = len(device_list)
        i = i % length
        yield device_list[i]
        i += 1


device_list = ['192.168.26.102:5555', '192.168.26.101:5555']
i = 0
device_obj = generate_device(device_list, i)


def pytest_collect_file(parent, path):

    if path.ext == ".yaml" and path.basename.startswith("test"):
        device = next(device_obj)
        return File(path, parent, device)
    if path.ext == ".json" and path.basename.startswith("test"):
        device = next(device_obj)
        return File(path, parent, device)
    # todo with server data


class File(pytest.File):
    """
    return: case
    """

    def __init__(self, path, parent, device):
        super().__init__(path, parent)
        self.device = device
        # self.driver = u2.connect(device)
        self.driver = device
        global driver
        driver = self.driver
        self.path = path

    def setup(self):
        log.log.info("the device -{}- start run path: {}".format(self.device, self.path))
        self.driver.app_start('tv.danmaku.bili')

    def teardown(self):
        log.log.info('the device -{}- run end path: {}'.format(self.device, self.path))
        self.driver.app_stop('tv.danmaku.bili')

    def collect(self):
        import yaml
        cases = yaml.safe_load(self.fspath.open())

        for case in cases:
            desc = case.get('desc', '')
            level = case.get('level', '')
            marker = case.get('marker', '')
            parametrize = case.get('parametrize', None)

            if marker:
                self.add_marker(marker)

            if parametrize:

                parametrize_case_list = U.get_parametrize_case(case)
                for new_case in parametrize_case_list:
                    string = str(new_case.get('name')) + str(desc) + str(level)
                    log.log.info(new_case)

                    yield FileItem(string, self, new_case, self.driver, self.device)
            if not parametrize:
                case_name = case.get('name', None)
                string = str(case_name) + str(desc) + str(level)
                yield FileItem(string, self, case, self.driver, self.device)


class FileItem(pytest.Item):

    def __init__(self, case_name, parent, case, driver, device, config=None, session=None):
        super().__init__(case_name, parent, config, session)
        self.case = case
        self.driver = driver
        self.case_name = case_name
        self.device = device

    def setup(self):
        log.log.info('the running case id is:{}'.format(self.nodeid))
        log.log.info('ttttttt:{}'.format(dir(self)))

    def teardown(self):
        log.log.info("case id was ran over: {}".format(self.nodeid))
        log.log.info(self.own_markers)
        # # self.driver_obj = Driver(self.device)
        # self.device.app_stop('tv.danmaku.bili')

    def runtest(self, ):
        from step_parse import Action
        steps = self.case.get('steps', None)
        log.log.info('the device -{}- is running case:{}'.format(self.device, self.case.get('name', None)))
        for step in steps:
            try:
                import time
                time.sleep(1)
                # assert False
                # step_obj = Action(self.driver_obj.get_driver(), step)
                # step_obj.action()
            except:
                raise exception.CaseFail(self, 'step execution failed: {}'.format(step))

    def add_report_section(self, when, key, content):
        """
        Adds a new report section, similar to what's done internally to add stdout and
        stderr captured output::

            item.add_report_section("call", "stdout", "report section contents")

        :param str when:
            One of the possible capture states, ``"setup"``, ``"call"``, ``"teardown"``.
        :param str key:
            Name of the section, can be customized at will. Pytest uses ``"stdout"`` and
            ``"stderr"`` internally.

        :param str content:
            The full contents as a string.
        """
        if when == 'call':
            self._report_sections.append((when, key, content))

    def repr_failure(self, excinfo):
        """ called when self.runtest() raises an exception. """
        from exception import CaseFail
        if isinstance(excinfo.value, CaseFail):
            return "\n".join(
                [
                    "Failed: %r: %r" % excinfo.value.args[0:2],
                ]
            )

    def reportinfo(self):
        return self.fspath, 0, "Failures Case:{}".format(self.case_name)

# **********************************************************************************************
from _pytest.runner import runtestprotocol
from _pytest.runner import pytest_runtest_makereport


driver = None

# @pytest.hookimpl(hookwrapper=True)
# def pytest_runtest_makereport(item, call):
#     pytest_html = item.config.pluginmanager.getplugin('html')
#     outcome = yield
#     report = outcome.get_result()
#     extra = getattr(report, 'extra', [])
#     report.nodeid = report.nodeid.encode("utf-8").decode("unicode_escape")
#     if report.when == 'call':
#         # always add url to report
#         image = screen_shoot()
#         extra.append(pytest_html.extras.url(image))
#         xfail = hasattr(report, 'wasxfail')
#         if (report.skipped and xfail) or (report.failed and not xfail):
#             # only add additional html on failure
#             extra.append(pytest_html.extras.html('<div>Additional HTML</div>'))
#         report.extra = extra
# #
# #
# def screen_shoot():
#     '''
#     截图操作
#     pic_name:截图名称
#     :return:
#     '''
#     try:
#         fail_time = time.strftime('%Y%m%d%H%M%S', time.localtime(time.time()))
#         fail_pic = str(fail_time)
#         pic_name = os.path.join('E:\\AppTest\\AppTest-master\\pytest_1\\report', fail_pic)
#         driver.screenshot("{}.jpg".format(pic_name))
#         a = 'E:\\AppTest\\AppTest-master\\pytest_1\\report\\{}.jpg'.format(fail_pic)
#         return a
#     except Exception as e:
#         log.log.info(e)

# def pytest_addoption(parser):  # 定义命令行传参参数
#     parser.addoption("--device", action="store", default="device", help="None")
#
#
# @pytest.fixture(scope="session")  # 命令行参数传递给pytest
# def device(request):
#     return request.config.getoption("--device")
#
#
# @pytest.fixture(scope="module", autouse=True)
# def driver(device):
#     import uiautomator2 as u2
#     d = u2.connect(device)
#     d.app_start('tv.danmaku.bili')
#     d.set_fastinput_ime(True)
#     yield d
#     print("driver finished")
#     d.app_stop('tv.danmaku.bili')
#     d.close()
# '--collect-only'
#'-k', 'register and P0'
# -m, 'xxx'
if __name__ == '__main__':
    pytest.main(['--collect-only', '-v', '-s', '--html=./report.html', '-n', str(len(device_list)), ])
    # pytest.main(['-v', '-s', '--alluredir=./report', '-n', str(len(device_list))])

    # def run_case(de):
    #     pytest.main(['-v','test.json','--html=./report_{}.html'.format([de]), '--device={}'.format(de)])
    # from multiprocessing.dummy import Pool
    # p = Pool(len(device_list))
    # p.map(run_case, device_list)
    # p.close()
    # p.join()
    # import os
    # #
    # def all_file_path(root_directory):
    #     file_list = []
    #     for parent, dirnames, filenames in os.walk(root_directory):
    #         for filename in filenames:
    #             if filename.endswith('.json') or filename.endswith('yaml') and filename.startswith('test'):
    #                 # _path = parent + "\\" + filename
    #                 # print(_path)
    #                 file_list.append(filename)
    #     return file_list
    #
    # def __distribute(case_list, n):
    #     if not isinstance(case_list, list):
    #         raise('must be list')
    #     for i in range(0, len(case_list), n):
    #         yield case_list[i:i + n]
    #
    #
    # def distribute_case(case_list, devices):
    #     """
    #     distribute case for every device
    #     :param case_list:
    #     :param devices:
    #     :return:
    #     """
    #     obj = __distribute(case_list, len(devices))
    #     devices_case_dict = {}
    #     for device in devices:
    #         devices_case_dict[device] = []
    #     for l in obj:
    #         for index, device in enumerate(devices):
    #             try:
    #                 devices_case_dict[device].append(l[index])
    #             except:
    #                 pass
    #     return devices_case_dict
    #
    # case_path_list = all_file_path('E:\AppTest\AppTest-master\pytest_1')
    # case_dict = distribute_case(case_list=case_path_list, devices=device_list)
    # print(case_dict)
    #
    # def run_case(device):
    #     cases = case_dict.get(device, None)
    #     cases_str = str(cases).strip('[]')
    #     pytest.main(['test.json', '-s', '--html=./report_{}.html'.format([device.split(':')][0]), '--device={}'.format(device)])
    #
    # from multiprocessing.dummy import Pool
    # p = Pool(len(device_list))
    # p.map(run_case, device_list)
    # p.close()
    # p.join()
    # print(vars())
