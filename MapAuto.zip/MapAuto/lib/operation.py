# -*- coding: utf-8 -*-
# @Time    : 2017/9/21 17:05
# @Author  : tuihou
# @File    : operation.py
import exception


class Operation(object):

    def __init__(self, driver):

        self.driver = driver

    def find_element(self, kinds, element):

        if kinds.lower in ['id', 'resourceId']:
            el = self.driver(resourceId=element)
        elif kinds.lower in ['classname', 'clsname']:
            el = self.driver(className=element).click()
        elif kinds.lower in ['text']:
            el = self.driver(text=element)
        elif kinds.lower in ['des', 'description']:
            el = self.driver(description=element)
        elif kinds.lower in ['xpath']:
            el = self.driver.xpath(element)
        else:
            raise exception.ElementValueError('\'{}\' is invalid, please check it')
        return el

    def find_elements(self, kinds, element, index):
        length = self.find_element(kinds, element)
        if isinstance(int, index) and index<length and length!=0:
            self.find_element(kinds, element)[index]
        else:
            raise exception.ParamsValueError('index is invalid , list index out of range')

    def input(self, kinds, element, text):
        a = self.find_element(kinds, element)
        a.clear_text()
        a.set_text(text)

    def click(self, kinds, element):
        self.find_element(kinds, element).click()








