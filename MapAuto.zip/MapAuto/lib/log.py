# -*- coding: utf-8 -*-
# @Time    : 2017/9/14 16:14
# @Author  : tuihou
# @File    : logger.py

import logging
from logzero import setup_logger
import os
from lib import Utils
import time

config = Utils.ConfigIni()
project_path = config.get_ini('path', 'log')
today = time.strftime('%Y-%m-%d')
logfile_path = project_path
if not os.path.exists(logfile_path):
    os.mkdir(logfile_path)

_path = project_path + str(today)+'.log'
log = setup_logger(name="Info", logfile=_path, level=logging.INFO)
# logger_error=setup_logger(name="Error", logfile="E:\projects\coding\debug_2\log\Error.log", level=logging.ERROR)

if __name__ == '__main__':
    log.info("test")