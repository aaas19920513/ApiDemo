# -*- coding: utf-8 -*-
# @Time    : 2017/9/14 18:00
# @Author  : tuihou
# @File    : step_parse.py


import exception
import validator
from po import base
from lib import operation as Op


class Action(object):

    def __init__(self, driver, step):
        self.driver = driver
        self.step = step

    def run_func(self, CLASS, func):
        """
        run func if the class have function "func"
        :param page:
        :param func:
        :return:
        """
        try:
            func = getattr(CLASS, func)
        except:
            raise exception.ParamsValueError('the {0} is invalid!!! {1} have not {0} function'.format(func, CLASS))
        return func

    def action(self, ):
        """
      {
          "times": 1 ,
          "name": "test",
          "operation": "click",
          "element": "",
          "args": "",
          "image": "",
          "validate": [
            {
              "element": "",
              "text": "",
              "exist": ""
            },
            {
              "image": ""
            }
          ]
      }
        :return:
        """
        ope_obj = Op.Operation(self.driver)
        operation = self.step.get('operation', None)
        element = self.step.get('element', None)
        element_type = self.step.get('type', None)
        args = self.step.get('args', None)
        validate = self.step.get('validate', None)
        base_function = self.run_func(ope_obj, operation)
        image = self.step.get('step', None)

        # run operation
        try:
            # 带参数执行
            if args:
                base_function(element_type, element, args)
            # 不带参数执行
            base_function(element_type, element)
        except:
            raise exception.ParamsValueError('function -{}- run error, maybe params error, please check the '
                                             'function how to work'.format(operation))

        # validate
        if validate:
            obj = validator.Validate(self.driver)
            obj.is_exist(element)
            if validate['text']:
                obj.check_text(validate['text'], element)

        # todo
        if image:
            pass


