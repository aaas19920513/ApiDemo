# encoding: utf-8
from assertpy import assert_that
from lib import log


""" validate data format
TODO: refactor with JSON schema validate
"""


###############################################################################
##   testcase validator utils
###############################################################################

from selenium.webdriver.support.ui import WebDriverWait


class Validate(object):

    def __init__(self, driver):
        self.driver = driver

    def is_exist(self, *loc):
        WebDriverWait(self.driver, 15).until(lambda driver: driver.find_element(*loc).is_displayed())
        return assert_that(self.driver.find_element(*loc)).is_not_none()

    def check_text(self, text, *loc):
        WebDriverWait(self.driver, 15).until(lambda driver: driver.find_element(*loc).is_displayed())
        ele_text = self.driver.find_element(*loc).text()
        if ele_text is None:
            ele_text = self.driver.find_element(*loc).get_attribute('name')

        return assert_that(ele_text).contains(text)
