# -*- coding: utf-8 -*-
# @Time    : 2017/9/14 15:58
# @Author  : tuihou
# @File    : exception.py


class BaseError(Exception):
    pass


class StructureOrPathError(BaseError):
    pass


class ElementValueError(BaseError):
    pass


class ParamsValueError(BaseError):
    pass


class DriverError(BaseError):
    pass


class CaseFail(BaseError):
    pass
