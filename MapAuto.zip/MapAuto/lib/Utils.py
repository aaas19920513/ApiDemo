# -*- coding: utf-8 -*-

import time
import subprocess
import os
import configparser
import copy


def get_now_time():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))


def sleep(s):
    return time.sleep(s)


def cmd(cmd):
    return subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=1, close_fds=False)


class ConfigIni(object):
    def __init__(self):
        self.current_directory = os.path.split(os.path.realpath(__file__))[0]
        self.path = os.path.split(__file__)[0].replace('lib', 'data/test_info.ini')
        self.cf = configparser.ConfigParser()
        self.cf.read(self.path)

    def get_ini(self, title, value):
        return self.cf.get(title, value)

    def set_ini(self, title, value, text):
        self.cf.set(title, value, text)
        with open(self.path, 'w') as f:
            self.cf.write(f)
        # return self.cf.write(open(self.path, "wb"))

    def add_ini(self, title):

        self.cf.add_section(title)
        with open(self.path, 'w') as f:
            self.cf.write(f)

    def get_options(self, data):
        # 获取所有的section
        options = self.cf.options(data)
        return options


def find_parametrize_key(steps):

    key_list = []
    for index, step in enumerate(steps):
        for key, value in step.items():
            # v是不是变量 ， 且以$开头
            if isinstance(value, str):
                if value.startswith('$'):
                    key_list.append((index, key))
    return key_list


def get_parametrize_case(case):
    """

    :param case:                case 如下
    :return:                    参数化后的case
    """
    """
    [
  {
   "name": "register",
    "desc": "login",
    "level": "P0",
    "parametrize": [["name1", "admin12"], ["name2", "admin2222"]],
    "marker": "android",
   "steps": [{
          "times": 1 ,
          "name": "input_username",
          "operation": "click",
          "element": "//*[@resource-id=\"tv.danmaku.bili:id/navigation\"]/android.widget.ImageView[1]",
          "type": "xpath",
          "args": "$name",
          "image": ""
   },
     {
          "times": 1 ,
          "name": "input_password",
          "operation": "click",
          "element": "//*[@resource-id=\"tv.danmaku.bili:id/navigation\"]/android.widget.ImageView[1]",
          "type": "xpath",
          "args": "$password",
          "image": ""
   }
   ]
  },
    {
   "name": "login",
    "parametrize": [{"name": ["name1", "name2"]}],
   "steps": [{
          "times": 1 ,
          "name": "click button",
          "operation": "click",
          "element": "//*[@resource-id=\"tv.danmaku.bili:id/navigation\"]/android.widget.ImageView[1]",
          "type": "xpath",
          "args": "",
          "image": ""
   }]
  }
]
    """
    steps = case.get('steps', [])
    case_name = case.get('name', None)
    parametrize_values = case.get('parametrize', [])
    parametrize_keys = find_parametrize_key(steps)
    for case_index, params in enumerate(parametrize_values):
        for params_index, key in enumerate(parametrize_keys):
            step_index = key[0]
            k = key[1]
            steps[step_index][k] = params[params_index]
            case['name'] = case_name + str(case_index)
        cpcase = copy.deepcopy(case)
        cpcase.pop('parametrize')
        yield cpcase

if __name__ == '__main__':
    i = ConfigIni()
    i.add_ini('test')
    # i.set_ini('test', 'tttt', 'ddfff')
