# -*- coding: utf-8 -*-

import lib.Utils as U
from lib.adbUtils import ADB
import yaml
from lib.log import log


def get_device():
    """

    :return: 返回Android设备列表
    """

    android_devices_list = []
    for device in U.cmd('adb devices').stdout.readlines():
        if 'device' in device.decode() and 'devices' not in device.decode():
            device = device.decode().split('\t')[0]
            android_devices_list.append(device)

    return android_devices_list


def set_device_yaml():
    """
    获取当前设备的Android version并且保存到yaml里
    :return:
    """
    device_lst = []
    for device in get_device():
        adb = ADB(device)
        log.info(
            'get device:{},Android version:{}'.format(
                device, adb.get_android_version()))
        device_lst.append({'platformVersion': adb.get_android_version(
        ), 'deviceName': device, 'platformName': 'Android'})

    ini = U.ConfigIni()

    with open(ini.get_ini('test_device', 'device'), 'w') as f:
        yaml.dump(device_lst, f)
        f.close()


if __name__ == '__main__':
    set_device_yaml()
