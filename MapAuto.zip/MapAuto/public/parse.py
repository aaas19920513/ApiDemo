# -*- coding: utf-8 -*-
# @Time    : 2019/9/18 16:34
# @Author  : tuihou
# @File    : parse.py


from lib import log
import threading
import exception
from po import BasePage
from public import validator
from appium import webdriver


class StartDriver(object):
    _instance_lock = threading.Lock()

    def __init__(self, auto_type, device_info):
        self.auto_type = auto_type
        self.log = log.log
        self.device_info = device_info

    def __new__(cls, *args, **kwargs):
        if not hasattr(StartDriver, "_instance"):
            with StartDriver._instance_lock:
                if not hasattr(StartDriver, "_instance"):
                    StartDriver._instance = object.__new__(cls)
        return StartDriver._instance

    def start_driver(self):
        try:
            if self.auto_type.lower() in ['android', '安卓', 'a']:
                return self.__start_android_dr()

            if self.auto_type.lower() in ['ios', '苹果']:
                return self.__start_ios_dr()
            else:
                return self.__start_web_dr()
        except exception.DriverError as e:
            self.log(e)
            raise ('start driver error{}'.format(e))

    def __start__webdriver(self, device_info):
        desired_caps = {

            'platformName': device_info['platform'],

            'deviceName': device_info['name'],

            'platformVersion': device_info['version'],

            'appPackage': 'com.taobao.taobao',

            'appActivity': 'com.taobao.tao.welcome.Welcome',

            'unicodeKeyboard': True,

            'resetKeyboard': True

        }

        dr = webdriver.Remote('http://127.0.0.1:4444/wd/hub', desired_caps)
        return dr

    def __start_android_dr(self):
        return

    def __start_ios_dr(self):
        pass

    def __start_web_dr(self):
        pass


class ParseStep(object):
    """
    [{
    'action_type':"",
    'name':'',
    'times': '',
    "case":[{},{},{},]
    },{}]
    """

    def __init__(self, step_datas, action_type):
        self.step_datas = step_datas
        self.driver = StartDriver.start_driver(action_type)

    @staticmethod
    def run_func(cls_obj, func):
        """
        run func if the class have function "func"
        :param page:
        :param func:
        :return:
        """
        try:
            func = getattr(cls_obj, func)
        except:
            raise exception.ParamsValueError('the {0} is invalid!!! {1} not have the {0} function'.format(func, cls_obj))
        return func

    def parse(self):
        for step in self.step_datas:
            operation = step.get('operation', None)
            contcol_type = step.get('control_type', None)
            element = step.get('element', None)
            args = step.get('args', None)
            validate = step.get('validate', None)
            base_function = self.run_func(BasePage.Action(self.driver), operation)

            try:
                if args:
                    base_function(contcol_type, element, args)
                base_function(contcol_type, element)
            except:
                raise exception.ParamsValueError(
                    '{} run error, maybe params error, please check the function how to work')

            # validate
            if validate:
                obj = validator.Validate(self.driver)
                obj.is_exist(element)
                if validate['text']:
                    obj.check_text(validate['text'], element)




